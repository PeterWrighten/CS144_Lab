from __future__ import with_statement

import json
import SOAPpy
# SOAPpy.Config.debug = 1
SOAPpy.Config.buildWithNamespacePrefix = 0
from SOAPpy import SOAPProxy 
import math
import shutil
import time
import os
from os import path
from optparse import OptionParser

CURRENT_QUARTER = 'Autumn 2009'

WS_URL = 'https://cs198.stanford.edu/cs106/Backend/EnrollmentService.asmx'
WS_NAMESPACE = 'http://cs198.stanford.edu/'
WS_PASSWORD = 'bl@zb@z'
SLMAP_LOCATION = '/afs/ir.stanford.edu/users/f/r/frew/slmap'
SLMAP_NEW_LOCATION = '/afs/ir.stanford.edu/users/f/r/frew/slmap.new'
SLMAP_BACKUP_LOCATION = '/afs/ir.stanford.edu/users/f/r/frew/slmap.backup'

_server = SOAPProxy(WS_URL, namespace=WS_NAMESPACE,
                    soapaction = '%sCourseClasses' % WS_NAMESPACE)

cc = _server.CourseClasses(password=WS_PASSWORD)

_server.soapaction = '%sSectionSUNetIDMappingsForCourseClass' % WS_NAMESPACE

submission_dirs = {}
assignment_map_paths = {}
due_date_map = {}
late_policy_map = {}

import subprocess


def cmd(command):
    print "Running %s" % command
    process = subprocess.Popen(command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    if process.returncode != 0:
        print "Returned %d != 0. Output follows:" % process.returncode
        print stdout
        print "Stderr follows:"
        print stderr
        return False
    return True

def build_slmap(sec_to_sl_map, dry_run):
  print "Making new slmap dir: %s" % SLMAP_NEW_LOCATION
  if not dry_run:
    os.makedirs(SLMAP_NEW_LOCATION)

  for sectionee, values in sec_to_sl_map.items():
    slmap_dir = path.join(SLMAP_NEW_LOCATION, sectionee) 
    print "Making %s" % slmap_dir
    if dry_run:
      for course, sl in values.items():
        print "Writing entry: sec: %s class: %s SL: %s" % (sectionee, course, 
                                                           sl)
    else:
      os.mkdir(slmap_dir)
      with open(path.join(slmap_dir, 'slmap'), 'w') as slmap:
        cmd("fs setacl -dir %s -acl %s rl" % (slmap_dir, sectionee))
        for course, sl in values.items():
          slmap.write("%s:%s\n" % (course, sl)) 

  print "Migrating slmap directories"
  if not dry_run:
    shutil.rmtree(SLMAP_BACKUP_LOCATION, ignore_errors=True)
    os.rename(SLMAP_LOCATION, SLMAP_BACKUP_LOCATION)
    os.rename(SLMAP_NEW_LOCATION, SLMAP_LOCATION)

# Class days is an array of days the class meets
# 0 = Monday and so on
def class_late_days(submitted, due, class_days = [0, 2, 4]):
  days_late = 0
  cur = due
  while cur < submitted:
    cur_time = time.localtime(cur)
    if cur_time.tm_wday in class_days:
      days_late += 1
    cur += 24 * 3600
  return days_late

def twenty_four_hour_late_days(submitted, due):
  if submitted <= due:
    return 0
  return int(math.ceil((submitted - due) / (24.0 * 3600)))

late_policies = {'class' : class_late_days,
                 'calendar' : twenty_four_hour_late_days}

with open('/afs/ir.stanford.edu/users/f/r/frew/WWW/dirmap.json') as dirmap_file:
  dirmap = json.load(dirmap_file)
  course_info_map = dirmap['course_info'] 
  for course_name, specific_course_map in course_info_map.items():
    submission_dirs[course_name.lower()] = specific_course_map['submission_directory']
    assignment_map_paths[course_name.lower()] = specific_course_map['assignment_map']
    late_policy_map[course_name.lower()] = late_policies[specific_course_map['late_policy']]

for course_name, assignment_map_path in assignment_map_paths.items():
  print 'Opening %s' % assignment_map_path
  with open(assignment_map_path) as assignment_map_file:
    assignment_map = json.load(assignment_map_file)
    due_date_map[course_name] = {}
    for assignment in assignment_map:
      due_date_map[course_name][assignment['dir_name']] = time.mktime(time.strptime(assignment['due_date'], "%m/%d/%Y %H:%M:%S"))

class Submission(object):
  def __init__(self, submission_dir, class_name, assn, old_sl, new_sl, submitter, old_num, dry_run):
    self.submission_dir = submission_dir
    self.class_name = class_name
    self.assn = assn
    self.old_sl = old_sl
    self.new_sl = new_sl
    self.submitter = submitter
    self.old_num = old_num
    self.new_num = 1
    self.dry_run = dry_run

  def new_dir(self):
    return os.path.join(self.submission_dir, self.new_sl, self.assn, '%s%d' % (self.submitter, self.new_num))

  def old_dir(self):
    return os.path.join(self.submission_dir, self.old_sl, self.assn, '%s%d' % (self.submitter, self.old_num))

  def fix_backslashes(self):
    for dirpath, dirnames, filenames in os.walk(self.old_dir(), topdown=False):
      for name in dirnames + filenames:
        pathname = os.path.join(dirpath, name)
        new_pathname = pathname.replace('\\','/')
        if pathname != new_pathname:
          print "%s -> %s" % (pathname, new_pathname)
          if not dry_run:
            os.renames(pathname, new_pathname)

  def compute_submission_time(self):
    old_dir = self.old_dir()
    old_dir_stat = os.stat(old_dir) 
    # stat[8] == mtime, stat[9] == ctime
    min_time = min(old_dir_stat[8], old_dir_stat[9])
    for dirpath, dirnames, filenames in os.walk(self.old_dir()):
      for filename in filenames:
        filepath = os.path.join(dirpath, filename)
        if os.path.islink(filepath):
          continue
        file_stat = os.stat(filepath)
        min_time = min(min_time, file_stat[8], file_stat[9])
    self.min_time = min_time
    return self.min_time

  def compute_late_days(self):
    return late_policy_map[self.class_name](self.min_time, 
                                            due_date_map[self.class_name].get(self.assn, 1893456000))
  
  def due_date_str(self):
    return time.strftime(
              '%m/%d/%Y %H:%M:%S',
              time.localtime(due_date_map[self.class_name].get(self.assn, 1893456000)))

  def submitted_time_str(self):
    return time.strftime(
              '%m/%d/%Y %H:%M:%S',
              time.localtime(self.min_time))

  def late_day_str(self):
    return "%s/%s/%s%d: %d days late (due: %s, submitted: %s)" % (
        self.new_sl, self.assn, self.submitter, self.new_num, self.compute_late_days(), 
        self.due_date_str(), self.submitted_time_str())

  def cmp_tuple(self):
    return (self.class_name, self.new_sl, self.assn, self.submitter, self.min_time)

  def __cmp__(self, other):
    return cmp(self.cmp_tuple(), other.cmp_tuple())

  def __repr__(self):
    return repr(self.cmp_tuple())

  def is_next_submission(self, other):
    return self.submitter == other.submitter and self.assn == other.assn 

  def set_new_num(self, new_num):
    self.new_num = new_num


def get_submissions_from_filesystem(sec_to_sl_map, dry_run):
  submissions = []
  for class_name, submission_dir in submission_dirs.items(): 
    for sl_name in os.listdir(submission_dir):
      sl_dir = os.path.join(submission_dir, sl_name)
      if os.path.isdir(sl_dir):
        for assn_name in os.listdir(sl_dir):
          assn_dir = os.path.join(sl_dir, assn_name)
          if os.path.isdir(assn_dir):
            for sub_name in os.listdir(assn_dir):
              sub_dir = os.path.join(assn_dir, sub_name)
              i = len(sub_name) - 1
              while i >= 0 and sub_name[i:].isdigit():
                i-=1
              sectionee_name = sub_name[:i+1] 
              # sectionee name is smallest prefix that matches an enrolled
              # sunetid - this comes into play when someone has numbers
              # at the end of their sunetid
              while i <= len(sub_name) and sectionee_name not in sec_to_sl_map:
                i+=1
                sectionee_name = sub_name[:i+1]
              if sectionee_name not in sec_to_sl_map:
                print "Got unparseable submission: %s" % sub_dir
              elif i+1 == len(sub_name):
                print "Got submission with no submission number"
              else:
                if class_name not in sec_to_sl_map[sectionee_name]:
                  print "%s has moved classes from %s to %s" % (sectionee_name, class_name, sec_to_sl_map[sectionee_name].keys()[0]) 
                else:
                  cur_sl = sec_to_sl_map[sectionee_name][class_name] 
                  submissions.append(Submission(submission_dir, class_name, assn_name, sl_name, cur_sl, sectionee_name, int(sub_name[i+1:]), dry_run))
  return submissions

from optparse import OptionParser
parser = OptionParser()
parser.add_option("-n", "--dry-run", action="store_true", dest="dry_run",
                  default=False,
                  help="Don't actually make any changes to the filesystem")
(options, args) = parser.parse_args()

print "Getting class info"
class_maps = {}
for courseclass in cc[0]:
    if (courseclass.QuarterName == CURRENT_QUARTER) and (courseclass.CourseID != '8'):
        courseID = courseclass.CourseID
        quarterID = courseclass.QuarterID
        sunetidmaps = _server.SectionSUNetIDMappingsForCourseClass(
            password=WS_PASSWORD, 
            courseID=courseID, 
            quarterID=quarterID) 
        if len(sunetidmaps) > 0 and len(sunetidmaps[0]) > 0:
          class_maps[courseclass.CourseName] = sunetidmaps[0]
          
print "Building student -> SL map"
sec_to_sl_map = {}
for class_name, classmap in class_maps.items():
  for sectionmap in classmap:
    slsunetid = sectionmap.SLSUNetID.lower()
    if sectionmap.SectioneeSUNetIDs:
        for secsunetid in sectionmap.SectioneeSUNetIDs[0]:
          sec_to_sl_map.setdefault(secsunetid, {})[class_name.lower()] = slsunetid

print "Rebuilding slmaps"
build_slmap(sec_to_sl_map, options.dry_run)

print "Getting submissions from filesystem"
submissions = get_submissions_from_filesystem(sec_to_sl_map, options.dry_run)

print "Correcting backslash stupidity"
for submission in submissions:
  submission.fix_backslashes()

print "Computing submission times"
for submission in submissions:
  submission.compute_submission_time()

print "Sorting!"
submissions.sort()

print "Renumbering submissions"
for i in range(1,len(submissions)):
  if submissions[i].is_next_submission(submissions[i-1]):
    submissions[i].set_new_num(submissions[i-1].new_num + 1)

submissions.reverse()

print "Doing submission moves"
for submission in submissions: 
  if submission.new_dir() != submission.old_dir():
    print "%s -> %s" % (submission.old_dir(), submission.new_dir()) 
    if not options.dry_run:
      parent_dir = path.dirname(submission.new_dir())
      if not path.exists(parent_dir):
        os.makedirs(parent_dir)
      if cmd("cp -Rp %s %s" % (submission.old_dir(), submission.new_dir())):
        cmd("rm -rf %s" % submission.old_dir())

# Late day processing temporarily disabled
#print "Late days"
#with open('/var/www/latedays/index.html', 'w') as late_day_page:
#  late_day_page.write('<html><pre>\n')
#  for submission in submissions:
#    late_day_page.write(submission.late_day_str() + '\n')
#  late_day_page.write('</pre></html>')
