package edu.stanford.cs106;

import org.eclipse.ui.IPageListener;
import org.eclipse.ui.IPartListener2;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWindowListener;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.IWorkbenchWindow;

public abstract class AbstractAllPartListener 
		implements IPageListener, IPartListener2, IWindowListener {
	public AbstractAllPartListener() {
		// System.out.println("Process workspace");
		IWorkbench workbench = CS106Plugin.getDefault().getWorkbench();
		for (IWorkbenchWindow window : workbench.getWorkbenchWindows()) {
			processWindow(window);
		}
		workbench.addWindowListener(this);
	}
	
	public void windowActivated(IWorkbenchWindow window) {
	}

	public void windowClosed(IWorkbenchWindow window) {
		// System.out.println("Window closed");
		window.removePageListener(this);
	}

	public void windowDeactivated(IWorkbenchWindow window) {
	}

	public void windowOpened(IWorkbenchWindow window) {	
		// System.out.println("Window opened");
		processWindow(window);
	}

	public void pageActivated(IWorkbenchPage page) {
	}

	public void pageClosed(IWorkbenchPage page) {
		// System.out.println("Page closed " + page.getLabel());
		page.removePartListener(this);
	}

	public void pageOpened(IWorkbenchPage page) {
		// System.out.println("Page opened " + page.getLabel());
		processPage(page);
	}
	
	protected void processWindow(IWorkbenchWindow window) {
		// System.out.println("Process window: " + window.toString());
		for (IWorkbenchPage page : window.getPages()) {
			processPage(page);
		}
		window.addPageListener(this);
	}
	
	protected void processPage(IWorkbenchPage page) {
		// System.out.println("Process page: " + page.getLabel());
		for (IViewReference view : page.getViewReferences()) {
			processPart(view);
		}
		page.addPartListener(this);
	}
	
	protected void processPart(IWorkbenchPartReference partRef) {
	}
	
	public void partActivated(IWorkbenchPartReference partRef) {
	}

	public void partBroughtToTop(IWorkbenchPartReference partRef) {
	}

	public void partClosed(IWorkbenchPartReference partRef) {
	}

	public void partDeactivated(IWorkbenchPartReference partRef) {
	}

	public void partHidden(IWorkbenchPartReference partRef) {
	}

	public void partInputChanged(IWorkbenchPartReference partRef) {
	}

	public void partOpened(IWorkbenchPartReference partRef) {
		processPart(partRef);
	}

	public void partVisible(IWorkbenchPartReference partRef) {
	}
}
