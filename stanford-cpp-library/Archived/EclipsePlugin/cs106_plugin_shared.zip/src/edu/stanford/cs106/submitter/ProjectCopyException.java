package edu.stanford.cs106.submitter;

public class ProjectCopyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8733270437674968012L;

}
