
package edu.stanford.cs106.ui;
 
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.ui.JavaElementLabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;

/**
 * A dialog to select a type from a list of types. Based on Penumbra's
 * MainTypeDialog, which was based on something undocumented from Eclipse.
 */

public class MainTypeSelector extends ElementListSelectionDialog {
	private final IType[] fTypes;
	private String argsString;
	private Text argsText;

	public MainTypeSelector(Shell shell, IType[] types) {
		super(shell, new JavaElementLabelProvider(
				JavaElementLabelProvider.SHOW_BASICS |
				JavaElementLabelProvider.SHOW_OVERLAY_ICONS |
				JavaElementLabelProvider.SHOW_ROOT));
		fTypes = types;
		setMessage("Choose a type to run");
		argsText = null;
		argsString = "";
	}

	/*public IType[] getTypes() {
		return fTypes;
	}*/

	public int open() {
		if (fTypes == null)
			return CANCEL;
		Object[] toAdd = new String[fTypes.length];
		
		for(int i = 0; i < fTypes.length; i++) {
			IType iType = fTypes[i];
			toAdd[i] = iType.getFullyQualifiedName();

			System.out.println(toAdd[i]);
		}
		
		setElements(fTypes);
		return super.open();
	}
	
	public void setCmdString(String cmdString) {
		this.argsString = cmdString;
	}
	
	public String getCmdString() {
		return this.argsString;
	}

	protected void computeResult() {
		super.computeResult();
		argsString = argsText.getText();
	}

	public Control createDialogArea(Composite parent) {
		Composite contents= (Composite) super.createDialogArea(parent);

		Label label = new Label(contents, SWT.SINGLE);
		label.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		label.setText("Command line arguments:");

		argsText = new Text(contents, SWT.SINGLE | SWT.BORDER);
		argsText.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		argsText.setText(this.argsString);		
					
		return contents;
	}
}