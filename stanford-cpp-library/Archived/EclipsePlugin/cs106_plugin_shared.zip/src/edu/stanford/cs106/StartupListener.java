package edu.stanford.cs106;

import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IPreferencesService;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.ILaunchesListener;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IStartup;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.intro.IIntroManager;

public class StartupListener implements IStartup {
	
	public void earlyStartup() {
		Display.getDefault().asyncExec(new Runnable(){
			public void run() {
				IIntroManager manager = CS106Plugin.getDefault().getWorkbench().getIntroManager();
				if (manager.getIntro() != null)
					manager.closeIntro(manager.getIntro());
			}
		});
		IPreferencesService prefs = Platform.getPreferencesService();
		if (prefs.getBoolean(CS106Plugin.PLUGIN_ID, "poorLifeChoicesProtection", false, null)) {
			new PoorLifeChoicesListener();
		}
		if (prefs.getBoolean(CS106Plugin.PLUGIN_ID, "threadFiltering", true, null)) {
			new ThreadFilterListener();
		}
		if (prefs.getBoolean(CS106Plugin.PLUGIN_ID, "resourceFiltering", false, null)) {
			System.out.println("Resource filtering enabled");
			new ResourceFilterListener();
		}
		
		CommitMessageHandler commitMessage = new CommitMessageHandler();
		
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		workspace.addResourceChangeListener(new LogChangeListener(commitMessage));
		//workspace.add
		
		ILaunchManager manager = DebugPlugin.getDefault().getLaunchManager();
		manager.addLaunchListener( new LogLaunchListener(commitMessage));
		
		/*if (prefs.getBoolean(CS106Plugin.PLUGIN_ID, "logging", false, null)) {
			// workspace.addResourceChangeListener(new LogChangeListener());
		}*/
		
		
	}

}
