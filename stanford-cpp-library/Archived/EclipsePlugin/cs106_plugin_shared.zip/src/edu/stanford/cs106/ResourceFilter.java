package edu.stanford.cs106;

import org.eclipse.debug.core.DebugException;
import org.eclipse.jdt.debug.core.IJavaThread;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

public class ResourceFilter extends ViewerFilter {

	protected ResourceFilter() {	
	}
	
	@Override
	public boolean select(Viewer viewer, Object parentElement, Object element) {
		if (element.getClass().getName().indexOf("LibraryContainer") >= 0) {
			return false;
		}
		if (element.getClass().getName().indexOf("ClassPathContainer") >= 0) {
			return false;
		}
		// System.out.println("Resource filter: " + element);
		return true;
	}
	
	protected static ResourceFilter singleton = new ResourceFilter();
	
	public static ResourceFilter getInstance() {
		return singleton;
	}
}
