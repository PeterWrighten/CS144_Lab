package edu.stanford.cs106;

import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jdt.ui.IPackagesViewPart;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartReference;

public class ResourceFilterListener extends AbstractAllPartListener {
	protected static class AddResourceFilterRunnable implements Runnable {
		protected IWorkbenchPartReference part;
		
		public AddResourceFilterRunnable(IWorkbenchPartReference part) {
			this.part = part;
		}
		
		public void run() {
			IWorkbenchPart fullPart = part.getPart(true);
			if (!(fullPart instanceof IPackagesViewPart)) {
				System.err.println("Got package explorer view that doesn't implement IPackagesViewPart: " + fullPart.getTitle());
				return;
			}
			IPackagesViewPart packageExplorerView = (IPackagesViewPart) fullPart;
			TreeViewer treeViewer = packageExplorerView.getTreeViewer();
			treeViewer.addFilter(ResourceFilter.getInstance());
		}
	}
	
	public void processPart(IWorkbenchPartReference part) {
		if ("org.eclipse.jdt.ui.PackageExplorer".equals(part.getId())) {
			Display.getDefault().asyncExec(new AddResourceFilterRunnable(part));
		}
	}
}
