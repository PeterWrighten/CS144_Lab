package edu.stanford.cs106.submitter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * A simple encapsulation of a single assignment.
 * 
 * @author frew, piech
 *
 */
public class Assignment {
	private Date dueDate;
	private String name;
	private String course;
	private String dirName;
	private boolean contest = false;
	private boolean log = false;
	
	public Date getDueDate() {
		return dueDate;
	}

	public String getName() {
		return name;
	}

	public String getDirectory() {
		return dirName;
	}
	
	public String getCourse() {
		return course;
	}

	/*
	 * This creates a new assignment object based on a JSONObject and course name.
	 * Updated by Jeremy Keeshin December 27, 2011
	 */
	public Assignment(String course, JSONObject description) {
		this.course = course;
		// Our assignment files assume Pacific Time. This isn't secure,
		// but we aren't expecting it to be. :)		
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		formatter.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
		try {
			name = description.getString("Name");
			dueDate = formatter.parse(description.getString("DueDate"));
			dirName = description.getString("DirectoryName");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	
	public String toString() {
		return course + " > " + name + " (" + dueDate + ")";
	}
	
	public boolean isContest() {
		return contest;
	}

	public boolean shouldLog() {
		return log;
	}
}
