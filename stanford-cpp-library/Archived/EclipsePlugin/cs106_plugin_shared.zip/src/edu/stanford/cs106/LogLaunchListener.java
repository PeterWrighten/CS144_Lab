package edu.stanford.cs106;

import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchesListener;

public class LogLaunchListener implements ILaunchesListener{

	private CommitMessageHandler handler;
	
	public LogLaunchListener(CommitMessageHandler handler) {
		this.handler = handler;
	}
	
	public void launchesAdded(ILaunch[] launches) {
		handler.addRun();
	}

	public void launchesChanged(ILaunch[] launches) {

	}

	public void launchesRemoved(ILaunch[] launches) {

	}

}
