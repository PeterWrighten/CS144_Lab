package edu.stanford.cs106;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.PartInitException;

public class PoorLifeChoicesListener extends AbstractAllPartListener {
	protected void mitigatePoorChoices(IWorkbenchPartReference partRef) {
		if ("org.eclipse.ui.views.ProblemView".equals(partRef.getId())) {
			MessageDialog dialog = new MessageDialog(
					CS106Plugin.getDefault().getWorkbench().getActiveWorkbenchWindow().getShell(), 
					"Confirm Poor Choice", null,
					"You're currently trying to close the problems view.\n" +
					"This view helpfully displays information on compilation errors " +
					"and warns you of possible problems.\n" +
					"Are you *sure* you want to do this?", 
					MessageDialog.QUESTION, 
					new String[] { 
						IDialogConstants.YES_LABEL,
	                    IDialogConstants.NO_LABEL }, 
	                    1); // no is the default
	        // Let them do it if they selected yes.
			if (dialog.open() == 0) return;
			
			// Save them if they didn't.
			Display d = Display.getCurrent();
			d.asyncExec(new Runnable() {
				public void run() {
					IWorkbench workbench = CS106Plugin.getDefault().getWorkbench();
					IWorkbenchPage page = workbench.getActiveWorkbenchWindow().getActivePage();
					try {
						page.showView("org.eclipse.ui.views.ProblemView");
					} catch (PartInitException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			
		}
	}
	
	public void partClosed(IWorkbenchPartReference partRef) {
		mitigatePoorChoices(partRef);
	}
}
