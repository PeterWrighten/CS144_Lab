package edu.stanford.cs106.submitter;

import org.eclipse.jface.dialogs.IPageChangedListener;
import org.eclipse.jface.dialogs.PageChangedEvent;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;

public class AssignmentSelectPage extends WizardPage implements IPageChangedListener {

	private Composite composite;
	private Text directory;
	private List assignmentList;
	private java.util.List<Assignment> assignments;
	
	public Assignment getSelectedAssignment() {
		String[] assignmentSelections = assignmentList.getSelection();
		if (assignmentSelections == null || assignmentSelections.length == 0) {
			return null;
		}
		String assignment = assignmentSelections[0];
		for (Assignment possibleMatch : assignments) {
			if (assignment.equals(possibleMatch.toString()))
				return possibleMatch;
		}
		return null;
	}
	
	protected AssignmentSelectPage() {
		super("Choose assignment");
		setDescription("Choose the assignment that you want to submit.");
	}

	public boolean isPageComplete() {
		return getSelectedAssignment() != null;
	}
	
	public void createControl(Composite parent) {
		composite = new Composite(parent, SWT.NONE);
	    composite.setLayout(new GridLayout(1, true));
	   	    
	    assignmentList = new List(composite, SWT.BORDER | SWT.V_SCROLL);
	    assignmentList.addSelectionListener(new SelectionAdapter(){
	    	public void widgetSelected(SelectionEvent e) {
				AssignmentSelectPage.this.getWizard().getContainer().updateButtons();
			}
	    });
	    // GridData assignmentListGD = new GridData();
	    // assignmentListGD.horizontalSpan = 2;
	    // assignmentListGD.horizontalAlignment = GridData.FILL;
	    // assignmentList.setLayoutData(assignmentListGD);
	    
	    GridData listData = new GridData(SWT.FILL, SWT.FILL, true, true);
	    
	    assignmentList.setLayoutData(listData);
	    setControl(composite);
	}

	public void initAssignmentList() {
		assignmentList.removeAll();
		long bestOffset = Long.MAX_VALUE;
		assignments = ((SubmitterWizard)getWizard()).getAssignments();
		int i = 0;
	    for (Assignment assignment : assignments) {
	    	long offset = 
	    		assignment.getDueDate().getTime() - System.currentTimeMillis();

	    	assignmentList.add(assignment.toString());
	    	if (offset >= 0 && offset < bestOffset) {
	    		bestOffset = offset;
	    		assignmentList.select(assignmentList.getItemCount() - 1);
	    	}
	    	i++;
	    }
        AssignmentSelectPage.this.getWizard().getContainer().updateButtons();
	}

	public void pageChanged(PageChangedEvent event) {
		System.out.println("Page changed");
		if (event.getSelectedPage().equals(this)) {
			System.out.println("To assignment page.");
			initAssignmentList();
		}
	}

}
