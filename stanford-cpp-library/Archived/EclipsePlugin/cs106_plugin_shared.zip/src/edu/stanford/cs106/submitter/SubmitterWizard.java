package edu.stanford.cs106.submitter;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.IPageChangeProvider;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.Wizard;

import com.sshtools.j2ssh.SftpClient;

public class SubmitterWizard extends Wizard {

	public boolean performFinish() {
		SubmitAction submit = new SubmitAction(this);
		try {
			this.getContainer().run(false, false, submit);
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return submit.wasSuccessful();
	}
	
	public void addPages() {
		authenticationPage = new AuthenticationPage();
		addPage(authenticationPage);
		assignmentSelectPage = new AssignmentSelectPage();
		if (pageChangeProvider != null)
			pageChangeProvider.addPageChangedListener(assignmentSelectPage);
		addPage(assignmentSelectPage);
		projectSelectPage = ProjectSelectPage.generateProjectSelectPage();
		
		addPage(projectSelectPage);
		setNeedsProgressMonitor(true);
	}
	
	/*public void setLoggingCheckBox(boolean logging) {
		if (projectSelectPage instanceof EclipseProjectSelectPage) {
			((EclipseProjectSelectPage) projectSelectPage).setLoggingCheckboxOn(logging);
		}
	}*/
	
	public void setPageChangeProvider(IPageChangeProvider provider) {
		if (assignmentSelectPage != null)
			provider.addPageChangedListener(assignmentSelectPage);
		pageChangeProvider = provider;
	}
	
	public List<Assignment> getAssignments() {
		return authenticationPage.getAssignments();
	}
	
	public void addClass(String course, String slName) {
		authenticationPage.addClass(course, slName);
	}
	
	public ISubmissionProducer getSubmissionProducer() {
		return projectSelectPage;
	}
	
	AuthenticationPage authenticationPage;
	AssignmentSelectPage assignmentSelectPage;
	ProjectSelectPage projectSelectPage;
	private IPageChangeProvider pageChangeProvider;
}
