package edu.stanford.cs106.submitter;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;

import com.sshtools.j2ssh.SshClient;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolState;
import com.sshtools.j2ssh.authentication.PasswordAuthenticationClient;
import com.sshtools.j2ssh.transport.IgnoreHostKeyVerification;

import edu.stanford.cs106.CS106Plugin;

public class AuthenticateAction implements IRunnableWithProgress {
	private String host;
	private String username;
	private String password;
	private String errorMessage;
	private SshClient ssh;
	private boolean authenticated;
	private AuthenticationCallback cb;
	
	public AuthenticateAction(String host, String username, String password,
							  AuthenticationCallback cb) {
		this.host = host;
		this.username = username;
		this.password = password;
		this.cb = cb;
	}

	public String getErrorMessage() {
		if (errorMessage != null) return errorMessage;
		return cb.getErrorMessage();
	}

	public SshClient getSsh() {
		return ssh;
	}

	public boolean isAuthenticated() {
		return authenticated;
	}

	public void run(IProgressMonitor monitor) throws InvocationTargetException,
			InterruptedException {
		ssh = new SshClient();
		monitor.beginTask("Authenticating", 4);
		try {
			checkIfPluginIsDepricated();
			ssh.connect(host, new IgnoreHostKeyVerification());
			monitor.worked(1);
			PasswordAuthenticationClient client = new PasswordAuthenticationClient();
			client.setUsername(username);
			client.setPassword(password);
			int result = ssh.authenticate(client);
			if (result != AuthenticationProtocolState.COMPLETE) {
				errorMessage = "Invalid SUNetID/password. Please verify that they're correct and try again.";
				return;
			}
			monitor.worked(1);
		} catch (IOException e1) {
			errorMessage = "Couldn't connect to the submission server (" + host
					+ "). Please try again later. " + e1.getLocalizedMessage();
			return;
		} catch (DepricatedException e2) {
			errorMessage = "This version of the Stanford Submitter is depricated. Please download "
				    + "an updated version of Stanford Eclipse.";
			return;
		}
		cb.initialize(username, ssh);
		cb.run(monitor);
		authenticated = cb.wasSuccessful();
	}

	private void checkIfPluginIsDepricated() throws DepricatedException {
		try {
			String codeName = CS106Plugin.getCodeName();
			for(String plugin : SubmissionInfo.getInstance().getDepricatedPlugins()) {
				if (plugin.equals(codeName)) {
					throw new DepricatedException();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
