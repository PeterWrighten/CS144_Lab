package edu.stanford.cs106.submitter;

import org.eclipse.jface.wizard.WizardPage;

public abstract class ProjectSelectPage extends WizardPage implements
		ISubmissionProducer {
	static ProjectSelectPage generateProjectSelectPage() {
		if (pageProviderClass == null) return null;
		try {
			return (ProjectSelectPage) pageProviderClass.newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	static Class pageProviderClass;
	
	static {
		// This is kind of a hack, but a real dependency injection
		// pattern is way to heavy weight.
		Class eclipsePageClass = null;
		Class standalonePageClass = null;
		
		try {
			eclipsePageClass = Class.forName(
					"edu.stanford.cs106.submitter.EclipseProjectSelectPage");
		} catch (ClassNotFoundException e) {
		}
		try {
			standalonePageClass = Class.forName(
					"edu.stanford.cs106.submitter.StandaloneProjectSelectPage");
		} catch (ClassNotFoundException e) {
		}
		
		if (eclipsePageClass == null && standalonePageClass == null) {
			System.err.println("Couldn't find either of the project select page classes");
			// TODO(frew): Better error
		}

		if (standalonePageClass != null) {
			pageProviderClass = standalonePageClass;
		}
		
		if (eclipsePageClass != null) {
			pageProviderClass = eclipsePageClass;
		}
		
	}
	
	protected ProjectSelectPage(String str) {
		super(str);
	}
}
