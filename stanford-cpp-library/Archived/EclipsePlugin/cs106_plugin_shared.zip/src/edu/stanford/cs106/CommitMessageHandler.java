package edu.stanford.cs106;

public class CommitMessageHandler {
	
	private String type;
	private int numRuns;
	
	void clear() {
		type = "";
		numRuns = 0;
	}
	
	void setType(String type) {
		this.type = type;
	}
	
	void addRun() {
		numRuns++;
	}
	
	String getMessage() {
		String typeString = "\"type\":\""+type+"\"";
		String runString = "\"runs\":\""+numRuns+"\"";
		return "{"+ typeString + ", " + runString +"}";
	}

}
