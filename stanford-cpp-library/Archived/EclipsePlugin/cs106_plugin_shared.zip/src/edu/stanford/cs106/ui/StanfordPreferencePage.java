package edu.stanford.cs106.ui;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import edu.stanford.cs106.CS106Plugin;

public class StanfordPreferencePage extends FieldEditorPreferencePage implements
		IWorkbenchPreferencePage {

	protected IPreferenceStore doGetPreferenceStore() {
		return CS106Plugin.getDefault().getPreferenceStore();
	}
	
	@Override
	protected void createFieldEditors() {
		// TODO(frew): Make this not suck.
		setMessage("Warning: Preferences may require a restart of Eclipse to take effect.");

		addField(new BooleanFieldEditor("poorLifeChoicesProtection",
										"Enable common mistakes protection (e.g. closing the Problems view)",
										getFieldEditorParent()));
		addField(new BooleanFieldEditor("threadFiltering",
										"Enable filtering of non-main threads",
										getFieldEditorParent()));
		addField(new BooleanFieldEditor("resourceFiltering",
										"Enable filtering of advanced resources (e.g. included external jars)",
										getFieldEditorParent()));
	}

	public void init(IWorkbench workbench) {
	}
}
