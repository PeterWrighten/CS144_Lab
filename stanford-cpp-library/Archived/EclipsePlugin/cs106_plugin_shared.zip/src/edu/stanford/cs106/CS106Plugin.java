package edu.stanford.cs106;

import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Preferences;
import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.core.runtime.preferences.DefaultScope;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IPreferencesService;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class CS106Plugin extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "edu.stanford.cs106";

	// The shared instance
	private static CS106Plugin plugin;

	// The plugin code name
	private static final String CODE_NAME = "giraffe";
	
	// The location of submission info
	public static final String SUBMITTER_INFO_FILE = "http://CS106a.stanford.edu/submitter/submitterInfoTest.json";
	
	/**
	 * The constructor
	 */
	public CS106Plugin() {
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static CS106Plugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the code name of the plugin
	 * 
	 * @return codeName
	 */
	public static String getCodeName() {
		return CODE_NAME;
	}

	public static class CS106PluginPreferenceInitializer extends AbstractPreferenceInitializer {
		@Override
		public void initializeDefaultPreferences() {
			IEclipsePreferences prefs = new DefaultScope().getNode(PLUGIN_ID);
			prefs.putBoolean("poorLifeChoicesProtection", true);
			prefs.putBoolean("threadFiltering", true);
			prefs.putBoolean("resourceFiltering", true);
		}	
	}
}
