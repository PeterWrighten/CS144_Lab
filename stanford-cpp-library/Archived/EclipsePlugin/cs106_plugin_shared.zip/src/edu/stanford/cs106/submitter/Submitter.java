package edu.stanford.cs106.submitter;

import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.sshtools.j2ssh.SshClient;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolState;
import com.sshtools.j2ssh.authentication.PasswordAuthenticationClient;

public class Submitter {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		FillLayout layout = new FillLayout();
		shell.setLayout(layout);
		SubmitterWizard sw = new SubmitterWizard();
		WizardDialog dialog = new WizardDialog(shell, sw);
		sw.setPageChangeProvider(dialog);
		dialog.setBlockOnOpen(true);
		dialog.open();
		shell.dispose();
		display.dispose();
	}
}
