package edu.stanford.cs106.submitter;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Shell;

public class PreviousSubmissionListing extends Dialog {

	public PreviousSubmissionListing(Shell parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

}
