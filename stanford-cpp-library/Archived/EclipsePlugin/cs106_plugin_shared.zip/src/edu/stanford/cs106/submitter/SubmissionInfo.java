package edu.stanford.cs106.submitter;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import edu.stanford.cs106.CS106Plugin;

public class SubmissionInfo {
	private String COURSE = "cs106a";
	
	private String submitHost;
	
	private String slMapDir;
	private String assignmentMapDir;
	private String submissionDir;
	
	private String slURLBase;
	private String assignmentURL;
	
	private List<String> depricatedPlugins;

	private boolean loggingOn;
	private String loggingSubmitDir;
	
	protected static boolean initSuccessful = false;
	protected static SubmissionInfo instance = null;
	
	private SubmissionInfo() throws IOException {
		depricatedPlugins = new ArrayList<String>();
		URL dirMapURL = new URL(CS106Plugin.SUBMITTER_INFO_FILE);
		InputStream dirMapStream = dirMapURL.openStream();
		try {
			JSONObject obj = new JSONObject(new JSONTokener(new InputStreamReader(dirMapStream)));
			
			System.out.println("Got JSON object in Submission Info: ");
			System.out.println(obj);
			
			submitHost = obj.getString("submit_host");
			slMapDir = obj.getString("sl_map_dir");
			assignmentMapDir = obj.getString("assignment_map_dir");
			assignmentURL = obj.getString("assignments_url");			
			slURLBase = obj.getString("sl_url_base");
			
			submissionDir = obj.getString("submission_dir");
			loadDepricatedPlugins(obj.getJSONArray("deprecated_submitters"));
			loggingOn = obj.getString("logging_on").equals("true");
			
			loggingSubmitDir = obj.getString("logging_submit_dir");
			
			initSuccessful = true;
		} catch (JSONException e) {
			throw new IOException("JSON Parsing error: " + e.getLocalizedMessage());
		}
	}

	private void loadDepricatedPlugins(JSONArray depricatedPluginsObj) throws JSONException {
		for (int i = 0; i < depricatedPluginsObj.length(); i++){
			JSONObject depricatedPlugin = depricatedPluginsObj.getJSONObject(i);
			String name = depricatedPlugin.getString("code_name");
			System.out.println("depricated: " + name);
			depricatedPlugins.add(name);
		}
	}
	
	public static SubmissionInfo getInstance() throws IOException {
		if (initSuccessful) return instance;
		instance = new SubmissionInfo();
		return instance;
	}
	
	public String getCourse() {
		return COURSE;
	}

	public String getSlMapDirectory() {
		return slMapDir;
	}
	
	public List<String> getDepricatedPlugins() {
		return depricatedPlugins;
	}
	
	public String getSubmitHost() {
		return submitHost;
	}

	public String getSlMapDir() {
		return slMapDir;
	}
	
	public String getSLURLBase(){
		return slURLBase;
	}
	
	public String getAssignmentsURL(){
		return assignmentURL;
	}

	public String getAssignmentMapDir() {
		return assignmentMapDir;
	}

	public String getSubmissionDir() {
		return submissionDir;
	}

	public boolean isLoggingOn() {
		return loggingOn;
	}

	public String getLoggingSubmitDir() {
		return loggingSubmitDir;
	}
}
