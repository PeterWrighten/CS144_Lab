package edu.stanford.cs106.submitter;

import org.eclipse.jface.operation.IRunnableWithProgress;

import com.sshtools.j2ssh.SshClient;

public abstract class AuthenticationCallback implements IRunnableWithProgress {
	protected String username;
	protected SshClient ssh;
	protected String errorMessage;
	protected boolean successful;
	
	public AuthenticationCallback() {
	}
	
	public void initialize(String username, SshClient ssh) {
		this.username = username;
		this.ssh = ssh;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public boolean wasSuccessful() {
		return successful;
	}
}
