package edu.stanford.cs106;

import org.eclipse.debug.core.DebugException;
import org.eclipse.jdt.debug.core.IJavaThread;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

public class ThreadFilter extends ViewerFilter {

	protected ThreadFilter() {	
	}
	
	@Override
	public boolean select(Viewer viewer, Object parentElement, Object element) {
		if (element instanceof IJavaThread) {
			IJavaThread thread = (IJavaThread) element;
			try {
				if (thread.isDaemon()) return false;
				if (thread.getName().indexOf("AWT-") >= 0 
					&& thread.getName().indexOf("AWT-Event") == -1) return false;
				if (thread.getName().indexOf("DestroyJavaVM") >= 0) return false;
			} catch (DebugException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return true;
			}
		} else {
			// System.err.println("Warning: " + element + " is not a IJavaThread as expected.");
		}
		return true;
	}
	
	protected static ThreadFilter singleton = new ThreadFilter();
	
	public static ThreadFilter getInstance() {
		return singleton;
	}
}
