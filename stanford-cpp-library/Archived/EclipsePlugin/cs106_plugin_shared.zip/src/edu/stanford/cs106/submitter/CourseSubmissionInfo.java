package edu.stanford.cs106.submitter;

public class CourseSubmissionInfo {

	private String assignmentMap;
	private String submissionDirectory;
	
	public String getAssignmentMap() {
		return assignmentMap;
	}
	
	public void setAssignmentMap(String assignmentMap) {
		this.assignmentMap = assignmentMap;
	}
	
	public String getSubmissionDirectory() {
		return submissionDirectory;
	}
	
	public void setSubmissionDirectory(String submissionDirectory) {
		this.submissionDirectory = submissionDirectory;
	}
	
}
