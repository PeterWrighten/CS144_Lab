package edu.stanford.cs106.submitter;

import java.io.File;

public interface ISubmissionProducer {
	public String getRoot();
	public File[] getSelectedFiles();
	//public boolean getLoggingOn();
}