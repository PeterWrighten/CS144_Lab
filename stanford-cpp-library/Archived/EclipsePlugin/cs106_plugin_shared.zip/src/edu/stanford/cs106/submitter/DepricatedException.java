package edu.stanford.cs106.submitter;

public class DepricatedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -417826366307418700L;


}
