package edu.stanford.cs106.ui;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.jdt.core.IJavaModel;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
import org.eclipse.jface.action.IAction;
import org.eclipse.ui.PlatformUI;

import edu.stanford.cs106.ui.MainTypeSelector;

public class RunFullAction extends RunAction {
	private static String cmdArgs = "";
	private static IType runClass = null;
	
	protected static String getRunArgs() {
		return cmdArgs;
	}
	
	protected static IType getRunClass() {
		return runClass;
	}

	public void run(IAction action) {
		IJavaModel model = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());

		IJavaProject[] projects = null;

		try {
			projects = model.getJavaProjects();
		} catch (JavaModelException jme) {

		}

		try {
			this.searchAndLaunch(ILaunchManager.DEBUG_MODE);
		} catch (InvocationTargetException e) {
			// TODO(frew): Blow up better
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO(frew): Blow up better
			e.printStackTrace();
		}
	}

	protected IType chooseType(IType[] types, String mode) {
		System.out.println("In chooseType");
		MainTypeSelector typeSelectorDialog = new MainTypeSelector(
				PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), 
				types);
		typeSelectorDialog.setTitle("Choose a Type to Run");
		typeSelectorDialog.setMultipleSelection(false);
		typeSelectorDialog.setCmdString(cmdArgs);

		if (typeSelectorDialog.open() == MainTypeSelector.OK) {
			runClass = (IType) typeSelectorDialog.getFirstResult();
			cmdArgs = typeSelectorDialog.getCmdString();

			return runClass;
		}
		return null;
	}
	
	protected void launch(IType type, String mode) {
		ILaunchConfiguration config = findLaunchConfiguration(type, mode);
		ILaunchConfigurationWorkingCopy wc = null;
		
		try {
			wc = config.getWorkingCopy();
			if (wc == null)
				return;
			wc.setAttribute(
				IJavaLaunchConfigurationConstants.ATTR_PROGRAM_ARGUMENTS,
					cmdArgs 
					+ " code=" + type.getFullyQualifiedName() + ".class"
					);
			config = wc.doSave();
		} catch (CoreException e) {
		}

		if (config != null) {
			DebugUITools.launch(config, mode);
		}
	}
}
