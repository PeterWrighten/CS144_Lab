package edu.stanford.cs106.ui;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
import org.eclipse.jface.action.IAction;

/**
 * Run the last configuration with fallback to type selection.
 * Based on Penumbra's PenumbraRunQuickly.
 * 
 * @author frew
 *
 */
public class RunQuickAction extends RunFullAction {
	public void run(IAction action) {
		IType runClass = getRunClass();
		
		if (runClass == null) {
			super.run(action);
		} else {
			launch(runClass, ILaunchManager.DEBUG_MODE);
		}
	}

	protected IType chooseType(IType[] types, String mode) {
		IType runClass = getRunClass();
		
		if (runClass == null) {
			return super.chooseType(types, mode);
		} else {
			return runClass;
		}
	}
	
	/**
	 * Launches a configuration for the given type
	 */
	protected void launch(IType type, String mode) {
		ILaunchConfiguration config = findLaunchConfiguration(type, mode);
		ILaunchConfigurationWorkingCopy wc = null;
		try {
			wc = config.getWorkingCopy();
			if (wc == null)
				return;
			wc.setAttribute(
				IJavaLaunchConfigurationConstants.ATTR_PROGRAM_ARGUMENTS,
				"code=" + type.getFullyQualifiedName() + ".class");
			config = wc.doSave();
		} catch (CoreException e) {
		}
		if (config != null) {
			DebugUITools.launch(config, mode);
		}
	}
}
