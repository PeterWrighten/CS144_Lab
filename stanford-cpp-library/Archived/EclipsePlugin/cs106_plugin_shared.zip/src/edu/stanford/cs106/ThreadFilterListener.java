package edu.stanford.cs106;

import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartReference;

public class ThreadFilterListener extends AbstractAllPartListener {
	protected static class AddThreadFilterRunnable implements Runnable {
		protected IWorkbenchPartReference part;
		
		public AddThreadFilterRunnable(IWorkbenchPartReference part) {
			this.part = part;
		}
		
		public void run() {
			IWorkbenchPart fullPart = part.getPart(true);
			if (!(fullPart instanceof IDebugView)) {
				System.err.println("Got debug view that doesn't implement IDebugView");
				return;
			}
			IDebugView debugView = (IDebugView) fullPart;
			Viewer viewer = debugView.getViewer();
			StructuredViewer structuredViewer = (StructuredViewer) viewer;
			structuredViewer.addFilter(ThreadFilter.getInstance());
		}
	}
	
	public void processPart(IWorkbenchPartReference part) {
		if ("org.eclipse.debug.ui.DebugView".equals(part.getId())) {
			Display.getDefault().asyncExec(new AddThreadFilterRunnable(part));
		}
	}
}
