#!/bin/bash

# Output shell commands
set -x
# Bail on errors
set -e

BASE_DIR=$(dirname $0)/dependencies

pushd $BASE_DIR
rm -rf *

mkdir swt
pushd swt
curl -O http://pointer.stanford.edu/cs198_buildfiles/swt/swt-3.5-cocoa-macosx.zip
curl -O http://pointer.stanford.edu/cs198_buildfiles/swt/swt-3.5-cocoa-macosx-x86_64.zip
curl -O http://pointer.stanford.edu/cs198_buildfiles/swt/swt-3.5-gtk-linux-x86.zip
curl -O http://pointer.stanford.edu/cs198_buildfiles/swt/swt-3.5-gtk-linux-x86_64.zip
curl -O http://pointer.stanford.edu/cs198_buildfiles/swt/swt-3.5-win32-win32-x86.zip

mkdir tmp
# Unzip all SWT arch zips to a directory named after their arch in tmp and create a folder for their jni libs in the current dir
ls *.zip | sed 's/\.zip$//g' | sed 's/^swt-3.5-//g' | xargs -n1 -I {} unzip swt-3.5-{}.zip -d tmp/{}
ls *.zip | sed 's/\.zip$//g' | sed 's/^swt-3.5-//g' | xargs -n1 -I {} mkdir -p {}/jni
pushd tmp
# Copy all the swt.jars 
find . -name 'swt.jar' | xargs -n1 -I {} cp {} ../{}
find . -name 'swt.jar' > /tmp/swtjars

# Unzip all of the swt jar files
for swtjar in $(cat /tmp/swtjars)
do
swtdir=$(dirname $swtjar)
unzip $swtjar -d $swtdir
done

# Find all the native libraries for SWT
find . | egrep '(so|jnilib|dll)$' > /tmp/jnilibs
for jnilib in $(cat /tmp/jnilibs)
do
jnilibname=$(basename $jnilib)
jnidir=$(dirname $jnilib)
cp $jnilib ../$jnidir/jni/$jnilibname
done

popd #tmp
rm -rf tmp
popd #swt

# We need a copy of Eclipse for JFace - it's all platform-independent
# so the particular one doesn't matter.
curl -O http://pointer.stanford.edu/cs198_buildfiles/eclipse/eclipse-SDK-3.5.1-macosx-cocoa.tar.gz
tar zxvf eclipse-SDK-3.5.1-macosx-cocoa.tar.gz

popd #BASE_DIR
